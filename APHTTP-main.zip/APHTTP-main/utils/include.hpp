#ifndef INCLUDE_HPP_INCLUDE
#define INCLUDE_HPP_INCLUDE

const std::string SERVER_NAME = "AP HTTP Server";
constexpr int BUFSIZE = 10 * 1024 * 1024; // 10MB

#endif // INCLUDE_HPP_INCLUDE
